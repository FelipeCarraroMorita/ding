from ding.functions import ding
