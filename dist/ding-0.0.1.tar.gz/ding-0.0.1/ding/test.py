import ding

ding.ding()