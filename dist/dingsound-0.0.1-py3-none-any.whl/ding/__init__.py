from dingsound.functions import ding
