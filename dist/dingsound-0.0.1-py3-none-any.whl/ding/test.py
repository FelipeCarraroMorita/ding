import dingsound

dingsound.ding()