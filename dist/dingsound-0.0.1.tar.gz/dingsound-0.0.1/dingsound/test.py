import dingsound

dingsound.ding()

